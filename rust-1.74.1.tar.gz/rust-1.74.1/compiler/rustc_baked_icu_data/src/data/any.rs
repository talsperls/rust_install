// @generated
impl_any_provider!(BakedDataProvider);
