mod collect_writes;

pub use collect_writes::FindAssignments;
