#!/usr/bin/env bash
exec ./y.sh test "$@"
