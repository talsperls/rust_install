//! Various optimizations specific to cg_clif

pub(crate) mod peephole;
