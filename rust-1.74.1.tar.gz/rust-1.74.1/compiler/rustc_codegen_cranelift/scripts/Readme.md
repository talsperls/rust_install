This directory is for scripts that are either never directly invoked or are not used very often.
Scripts that are frequently used should be kept at the project root.
