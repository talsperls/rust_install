Please read the rustc-dev-guide chapter on [Backend Agnostic Codegen][bac].

[bac]: https://rustc-dev-guide.rust-lang.org/backend/backend-agnostic.html
