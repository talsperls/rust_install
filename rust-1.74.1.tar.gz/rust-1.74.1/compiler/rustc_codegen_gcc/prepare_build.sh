#!/usr/bin/env bash
set -e
set -v

./build_sysroot/prepare_sysroot_src.sh
