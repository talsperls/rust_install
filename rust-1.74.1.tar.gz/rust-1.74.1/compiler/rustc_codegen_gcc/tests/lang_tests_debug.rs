mod lang_tests_common;

fn main() {
    lang_tests_common::main_inner(lang_tests_common::Profile::Debug);
}
